﻿// ReSharper disable once CheckNamespace
namespace IdParser
{
    public enum Validation
    {
        None,
        Strict
    }
}