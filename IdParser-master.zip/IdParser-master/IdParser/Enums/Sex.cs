﻿// ReSharper disable once CheckNamespace
namespace IdParser
{
    public enum Sex : byte
    {
        Male = 1,
        Female = 2,
        NotSpecified = 9
    }
}