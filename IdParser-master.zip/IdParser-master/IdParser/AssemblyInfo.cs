﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("IdParser.Test")]
